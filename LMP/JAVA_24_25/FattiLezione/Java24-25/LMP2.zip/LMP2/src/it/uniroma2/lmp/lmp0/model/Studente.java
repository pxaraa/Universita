/**
 *
 */
package it.uniroma2.lmp.lmp0.model;

/**
 *
 */
public interface Studente extends Persona {

    String getMatricola();

    void saluta(Professore professore);

}
